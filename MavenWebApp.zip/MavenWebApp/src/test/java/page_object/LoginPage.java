package page_object;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
		
		
		WebDriver ldriver;
		
		public LoginPage(WebDriver rdriver)
		{
			ldriver=rdriver ;
			PageFactory.initElements(rdriver, this);
		}
		
		@FindBy(id="login_email")
		WebElement txtUserid;
		
		@FindBy(id="login_password")
		WebElement txtpwd;
		
		@FindBy(xpath="//button[text()='Login']")
		WebElement login;
		
		public void setUserid(String uid)
		{
			txtUserid.sendKeys("shariq.abbas@authbridge.com");
		}
		
		public void setPassword(String pwd)
		{
			txtpwd.sendKeys("Auth@321");
		}
		
		public void clickLogin() 
		{
			login.click();
		}
		
	}


