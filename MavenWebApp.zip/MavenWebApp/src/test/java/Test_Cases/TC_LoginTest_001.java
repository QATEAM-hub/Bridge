package Test_Cases;


import org.testng.annotations.Test;

import page_object.LoginPage;

public class TC_LoginTest_001 extends BaseClass {
	
	@Test
	public void loginTest() 
	
	{
      driver.get(baseURL);
      LoginPage lp= new LoginPage(driver);
      lp.setUserid(userid);
      lp.setPassword(password);
      lp.clickLogin();
            
    }

}