package Test_Cases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import bridge_Utilities.ReadConfig;

public class BaseClass {
	
	ReadConfig readconfig = new ReadConfig();
	
	public String baseURL= readconfig.getApplicationURL();
	public String userid = readconfig.getUserid();
	public String password= readconfig.getpassword();
	public static WebDriver driver;
	
	@BeforeClass
	public void setup() 
	{
		System.setProperty("webdriver.gecko.driver",readconfig.getfirefox());
		driver= new FirefoxDriver();
	}

	@AfterClass
	public void tearDown() 
	{
		driver.quit();
	}
}
